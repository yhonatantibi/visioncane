# VisionCane 0.10.0 — indoor and outdoor descriptions

This release adds outdoor scene categories to the EXISTING ADE20K model output, without another model, cloud connection, API account or paid service.

New semantic categories interpreted from actual embedded metadata: road, sidewalk, path, fence, railing/bannister, pole, building, tree and step (stairs). Class IDs are never hard-coded. Road, sidewalk and pole observations receive high narration priority. A road spanning three image sectors is not narrated three times in one overview.

The existing object detector contributes people, cars, buses, trucks, bicycles, motorcycles, traffic lights, stop signs and benches. New question presets include road, sidewalk, traffic light and people. Vehicle questions support multiple vehicle classes. Region counts are not represented as object counts. Motion, traffic-light color, crossing permission and crosswalk questions do not produce fabricated answers.

This is description of a camera image, NOT navigation. No crosswalk detector, moving-vehicle tracker, traffic-light state classifier, GPS route guidance, curb/drop-off detector or clear-path guarantee is implemented. The additional category support does not establish real-world detection accuracy. Distance remains optional and uncalibrated. The reported tablet crash has not been verified fixed on a device.

Validation: automated tests cover category-to-region mapping, correct image sides, repeated-region suppression, question limits and narration priority. These are synthetic observations, not a field accuracy test.

Reference for supported labels: https://github.com/ultralytics/ultralytics/blob/main/ultralytics/cfg/datasets/ade20k.yaml

Upload both files from VisionCane-Upload-2-Files to the GitHub root without extracting the ZIP; start a NEW Codemagic android-demo build and install that build's APK. This folder holds source plus build configuration, not an APK.

---

# VisionCane 0.9.0 — scene questions and relevant overviews

User-visible changes from 0.7:
- Live camera with detector overlays, large describe/stop controls and speech mute.
- New Ask about the environment sheet: preset Hebrew questions and typed input, answers displayed immediately and spoken when speech is enabled. Automatic narration pauses while the sheet is open. Closing it interrupts the answer and leaves a quiet interval.
- Supported questions: where a listed object was detected, what was detected left/right/center, estimated distance when available, detection counts, and a current-view overview. Each answer reads evidence at submission time. No scene older than 2.5 seconds is used.
- Room overviews prioritize stairs, doors, people/vehicles and major furniture over small clutter. Wardrobes, cabinets, bookcases and dressers are included from actual semantic labels.
- Hebrew display labels expanded for the detector categories.
- Default live mode uses detector plus indoor model. Experimental depth is off unless enabled in settings before starting. Indoor input is 320 pixels, auxiliary models use CPU and load sequentially.

How to use: start detection, wait for camera/model readiness, press Ask about the environment, select Where is the door? / What is on the left? or type a supported question. Keep camera pointed at the scene. Distance questions report unavailable when depth is disabled or invalid.

Boundaries: questions use an offline rules-based interpreter over observed objects, NOT an open-ended language model. There is no microphone speech recognition in this release. Unknown relationships, colors, text, door-open state, safe crossings and whole-room maps are not inferred. No new object/road-crossing detector was added. The system does not identify everything.

Build and device status: source release for Codemagic, not a locally built APK. Unit/widget tests cannot establish real-device performance, reliable perception or crash resolution. This remains a demonstration candidate and must not be handed over as an independent navigation system.

Upload: the ZIP and codemagic.yaml from VisionCane-Upload-2-Files go together at the GitHub repository root. Do not extract the ZIP for upload. Run a new android-demo build and install its app-debug.apk. Never reuse an old build artifact.

---

# VisionCane 0.8.1 — demonstration candidate

This is source for a build, not a device-validated finished navigation product.

Changes:
- Live camera and object overlays, concise Hebrew scene narration, describe-now, door search, mute and stop controls.
- Indoor semantic model at 320 pixels on CPU. Depth is OFF by default: camera detector plus one indoor model, rather than three resident models. Experimental depth can be enabled before starting in settings, with higher resource use.
- Wardrobe, cabinet, bookcase and chest-of-drawers regions now enter narration using actual model metadata. Connected regions remain separate. No extra furniture model is loaded.
- Live screen shows room-model readiness and whether distance is enabled.
- Live auxiliary models are released before opening saved-photo analysis to avoid retaining duplicate sets of models.

Remaining limits:
- No device crash trace was available. Reduced model load is mitigation, not proof that the reported device crash is fixed.
- Door detection and speech quality require a real-device check. A door is not a verified exit or clear passage.
- Optional distances are uncalibrated model estimates. Image-left/right are relative to the camera, not a body bearing. There is no whole-room map or supported crossing guidance.
- First use still needs internet for the detector (and depth if enabled); the indoor model is bundled by CI. Offline voices must already be installed.

Build: upload the two files from VisionCane-Upload-2-Files to the repository root, without extracting the ZIP. Commit, run android-demo, install its new app-debug.apk. Old builds are unchanged.

Before tomorrow's demonstration: at a fixed seated position with a sighted helper, confirm camera starts, spoken left/right match the camera view, stop interrupts speech, and the app runs without freezing for ten minutes. Do not use this candidate to guide walking or road crossing. If startup fails, do not present it as a working assistive device.

---

# Current release: 0.7.0 prototype candidate

See [0.7.0 update and installation](docs/UPDATE-0.7.0.md). The indoor model is exported and verified during CI; native build and device validation are pending. Earlier status below is historical.

# VisionCane 0.5.0 — תיאור מרחבי משולב

נוסף ניתוח עצמים, מרחק ומבנה מאותה תמונה. ההקראה מפרטת שם, אחד מתשעה אזורי תמונה, ומרחק משוער במילים. כשהמרחק חסר או לא עקבי, לא מושמע מספר. קטגוריות מבניות מפוענחות מתוך מטא־דטה של המודל. תוצאות ישנות נדחות ויש תמונה אחת בלבד בעיבוד, בלי תור מתארך.

ברירת המחדל היא מצב משולב. אפשר לכבותו כשהמצלמה כבויה כדי לחזור לזיהוי הבסיסי. בהפעלה הראשונה נדרשים שני מודלים נוספים. מרחק המודל אינו מכויל, ומדרגות/דלתות שזוהו אינן בסיס להוראת ניווט או לאימות יציאה.

ה-analyzer עבר ללא ממצאים. 13 בדיקות מרחב חדשות, שמונה בדיקות לוגיקה קודמות ושבע בדיקות Node עברו. הפעלת שלושת המודלים על המכשיר ובניית 0.5 טרם אומתו. ראו docs/STATUS.md ו-docs/SPATIAL.md.

## היסטוריה: VisionCane 0.4.0

עודכן ב-21.10.2026. גרסת מועמד להדגמה, ממתינה לבניית ענן ולבדיקת מכשיר.

## מה חדש ביחס לגרסה שנבדקה בטאבלט

- תוקנה סיבה מוכחת לדחיית קול עברי מקומי: פענוח המחרוזת network_required="0" שמחזיר flutter_tts באנדרואיד.
- בחירה במנועי הקראה מותקנים, בדיקת הצלחת בחירת קול, מגבלת זמן וביטול הכנה בעת עצירה.
- מסך הדגמה פשוט בעברית, שליטה גדולה ונגישה, עצירת הכול, תיאור לפי בקשה ובחירה בתיאור אוטומטי.
- הפרדה בין הדגמה לכלי הניסוי, הודעת זיהוי תקוע ומניעת הצגת תוצאות ישנות.
- יומן ניסויי שטח הנשמר במכשיר, והעתקה/שיתוף של דוחות מלאים כקובץ.
- דוח אבחון של המצלמה והקול ללא תמונות או הקלטות.
- מסלול android-demo ב-Codemagic: בדיקה ובניית Android בלבד. המסלול המלא כולל גם Debug/Release ו-iOS ללא חתימה.
- מדריך הדגמה, התקנה, פרטיות, רישיונות ומצב האימות מצורפים תחת docs.

## אימות

שבע בדיקות Node, שמונה בדיקות עשן בלוגיקת Dart ובדיקת מבנה הפרויקט עברו. 17 קובצי Dart פוענחו ללא שגיאת תחביר. flutter analyze עבר ללא שגיאות בעותק הבדיקה, לפני תוספת הודעת התקיעה ורישיונות הרכיבים. נוסף מלאי של 34 בדיקות Flutter, כולל בדיקות לדחיית קול רשת, לפענוח 0/1, לביטול הכנת קול, לגופן מוגדל ולאחסון.

הרצת בדיקות Flutter והפקת APK מקומית נחסמו בבדיקת האישור האוטומטית בגלל ניסיון טלמטריה אל dc.services.visualstudio.com. לא ניתן לטעון שהבדיקות עברו, שה-APK הופק או שהתיקון פועל במכשיר. מסלול הענן מפעיל analyzer ואת כל הבדיקות כשער לפני הפקת APK.

## לפני הצגה למשתמשים

נדרשים: בנייה ירוקה של 0.4; קול מתוך האפליקציה במצב טיסה ו-Wi-Fi כבוי; עצירה ורקע; עשר דקות יציבות; בדיקת TalkBack על SM-X510. הפעלה באייפון עדיין דורשת חתימה ובדיקה פיזית. ראו docs/DEMO_GUIDE.md.

אין עדיין התרעות מרחק, מסלול הליכה, גילוי אמין של כל מכשולי הדרך או אישור לשימוש בהליכה עצמאית. רכיבים אלה דורשים פיתוח וכיול נוספים.
