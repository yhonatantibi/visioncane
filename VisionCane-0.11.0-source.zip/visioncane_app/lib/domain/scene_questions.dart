import 'scene_narrator.dart';
import 'spatial_scene.dart';

/// Bounded, offline questions over current observations, not a general chatbot.
class SceneQuestions {
  static const examples = ['מה רואים?', 'איפה הדלת?', 'מה משמאל?', 'מה מימין?',
    'איפה הארון?', 'מה המרחק למיטה?', 'איפה הכביש?', 'איפה המדרכה?', 'יש רמזור?', 'יש אנשים?'];

  static String answer(String question, SpatialScene? scene, int now) {
    final q = question.replaceAll(RegExp(r'[\u0591-\u05C7]'), '')
      .replaceAll(RegExp(r'[^א-תa-zA-Z0-9 ]'), ' ').trim().toLowerCase();
    if (q.isEmpty) return 'כתוב שאלה או בחר אחת מהשאלות המוכנות.';
    if (RegExp(r'מתקרב|מתרחק|נוסע|מהירות|מעבר חציה|מעבר חצייה').hasMatch(q)) {
      return 'אין כאן זיהוי אמין של תנועת כלי רכב או מעבר חצייה. אפשר לשאול היכן זוהו כלי רכב, כביש או מדרכה בתמונה.';
    }
    if (RegExp(r'לחצות|לעבור|ללכת|פנוי|בטוח|יציאה|פתוח|פתוחה|סגור|סגורה').hasMatch(q)) {
      return 'אין לי מידע שמאפשר לאשר מעבר בטוח, חצייה, מצב דלת או יציאה. אפשר לשאול מה זוהה בתמונה ובאיזה צד.';
    }
    if (scene == null || !scene.freshAt(now)) {
      return 'אין כרגע תמונה עדכנית שאפשר לענות לפיה. הפעל את המצלמה והמתן לזיהוי.';
    }
    if (RegExp(r'מאחור|מאחורי|מחוץ|כל החדר|מפה|איזה חדר|צבע|לובש|כתוב|קוראים|ליד|בין |מעל|מתחת|הכי|ביותר|בתוך|משמאל ל|מימין ל').hasMatch(q) ||
        RegExp(r'(^| )על( |$)').hasMatch(q) ||
        RegExp(r'(^| )לא( |$)').hasMatch(q)) {
      return 'אני יכול לתאר רק פרטים שזוהו בתמונת המצלמה הנוכחית. אפשר לשאול מה רואים, איפה חפץ או מה המרחק אליו.';
    }
    final all = <SpatialFeature>[];
    for (final f in scene.features.where((f) => f.box.valid)) {
      if (!all.any((old) => old.label == f.label && overlap(old.box, f.box) > .6)) all.add(f);
    }
    final requested = <String>{};
    for (final entry in _aliases.entries) {
      if (entry.value.any((word) => RegExp('(^| )[והבלמ]?${RegExp.escape(word)}( |\$)').hasMatch(q))) {
        requested.add(entry.key);
      }
    }
    if (q.contains('ארון ספרים')) { requested..remove('wardrobe')..remove('cabinet'); }
    if (q.contains('ארון בגדים')) requested.remove('cabinet');
    final left = q.contains('שמאל'), right = q.contains('ימין');
    final center = q.contains('מרכז') || q.contains('מולי');
    if ([left, right, center].where((v) => v).length > 1) {
      return 'שאל על כיוון אחד בכל פעם: שמאל, ימין או מרכז התמונה.';
    }
    var selected = all.where((f) => requested.isEmpty || requested.contains(f.label)).where((f) =>
      left ? f.box.x < 1/3 : right ? f.box.x > 2/3 : center ? f.box.x >= 1/3 && f.box.x <= 2/3 : true).toList();
    final distance = q.contains('מרחק') || q.contains('רחוק') || q.contains('קרוב');
    final count = q.startsWith('כמה') && !distance;
    final overview = const ['מה רואים', 'מה יש', 'תאר', 'סקירה', 'איפה אני'].any(q.startsWith);
    if (requested.isEmpty && !left && !right && !center && !overview) {
      return 'לא זיהיתי שאלה נתמכת. אפשר לשאול למשל: איפה הדלת, מה משמאל, כמה כיסאות זוהו, או מה המרחק למיטה.';
    }
    if (selected.isEmpty) {
      return 'לא זוהה בתמונה הנוכחית פרט שמתאים לשאלה. זה לא אומר שהוא אינו נמצא בסביבה.';
    }
    if (count) {
      if (selected.any((f) => f.structure)) return 'הזיהוי הזה מתאר אזורים בתמונה ואינו מאפשר ספירה אמינה שלהם.';
      return 'בתמונה הנוכחית זוהו ${selected.length} פרטים שמתאימים לשאלה. זו ספירת זיהויים, ולא ספירה מלאה של החדר.';
    }
    if (distance) {
      // Never rank unknown distances as far away or infer meters from box size.
      if (requested.isEmpty) return 'לגבי איזה חפץ? אפשר לשאול למשל מה המרחק למיטה.';
      if (selected.every((f) => f.depth == null)) {
        return '${SceneNarrator.describeFeatures(selected.take(3).toList(), prefix: 'בתמונה')} אין כרגע אומדן מרחק לפרטים האלה.';
      }
    }
    if (requested.isEmpty) {
      selected = SceneNarrator.selectOverview(selected, limit: 4);
    }
    return SceneNarrator.describeFeatures(selected.take(4).toList(), prefix: 'בתמונת המצלמה');
  }

  static const _aliases = <String, List<String>>{
    'door': ['דלת', 'דלתות'], 'window': ['חלון', 'חלונות'],
    'stairs': ['מדרגות'], 'person': ['אדם', 'אנשים', 'איש'],
    'chair': ['כיסא', 'כסא', 'כיסאות', 'כסאות'],
    'bed': ['מיטה', 'המיטה', 'מיטות'], 'dining table': ['שולחן', 'שולחנות'],
    'couch': ['ספה', 'ספות'], 'wardrobe': ['ארון', 'ארונות', 'ארון בגדים'],
    'cabinet': ['ארון', 'ארונות'], 'bookcase': ['ספרייה', 'ספריה', 'ארון ספרים'],
    'dresser': ['שידה', 'שידות'], 'tv': ['טלוויזיה', 'מסך'],
    'bottle': ['בקבוק', 'בקבוקים'], 'cup': ['כוס', 'כוסות'],
    'cell phone': ['טלפון'], 'laptop': ['מחשב'], 'refrigerator': ['מקרר'],
    'car': ['מכונית', 'מכוניות', 'רכב', 'רכבים'], 'bus': ['אוטובוס', 'רכב', 'רכבים'],
    'truck': ['משאית', 'רכב', 'רכבים'], 'bicycle': ['אופניים'], 'motorcycle': ['אופנוע'],
    'traffic light': ['רמזור', 'רמזורים'], 'stop sign': ['תמרור עצור'],
    'road': ['כביש'], 'sidewalk': ['מדרכה'], 'path': ['שביל'], 'pole': ['עמוד'],
    'fence': ['גדר'], 'railing': ['מעקה'], 'building': ['בניין'], 'tree': ['עץ'],
    'bench': ['ספסל'], 'dog': ['כלב'], 'cat': ['חתול'],
    'wall': ['קיר', 'קירות'], 'floor': ['רצפה'],
  };
}
