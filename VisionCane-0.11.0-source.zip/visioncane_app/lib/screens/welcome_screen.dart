import 'package:flutter/material.dart';
class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key, required this.onEnter});
  final void Function(BuildContext, bool) onEnter;
  @override
  Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: ConstrainedBox(
    constraints: const BoxConstraints(maxWidth: 620), child: ListView(padding: const EdgeInsets.all(28), children: [
      const SizedBox(height: 36),
      const Icon(Icons.visibility_outlined, size: 80, color: Color(0xFF55E4CE)),
      const SizedBox(height: 20),
      const Text('VisionCane', textAlign: TextAlign.center, style: TextStyle(fontSize: 38, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      const Text('להכיר את הסביבה, בקול.', textAlign: TextAlign.center, style: TextStyle(fontSize: 23)),
      const SizedBox(height: 36),
      Card(child: Padding(padding: const EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('שימוש יומיומי', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const Text('מצלמה, תיאור קולי ושאלות על הסביבה. ללא צורך בהרשמה.', style: TextStyle(fontSize: 18)),
        const SizedBox(height: 20),
        FilledButton(onPressed: () => onEnter(context, true), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(60)),
          child: const Text('כניסה לשימוש יומיומי')),
      ]))),
      const SizedBox(height: 16),
      OutlinedButton(onPressed: () => onEnter(context, false), style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(56)),
        child: const Text('כניסה למערכת הבדיקה הקיימת')),
      const SizedBox(height: 20),
      const Text('התיאור עלול לטעות. המערכת אינה תחליף למקל או להכוונת ניידות.', textAlign: TextAlign.center),
    ]),
  ))));
}
