import 'package:flutter/material.dart';
import '../domain/scene_questions.dart';

class SceneQuestionsSheet extends StatefulWidget {
  const SceneQuestionsSheet({super.key, required this.onQuestion});
  final Future<String> Function(String) onQuestion;
  @override
  State<SceneQuestionsSheet> createState() => _SceneQuestionsSheetState();
}

class _SceneQuestionsSheetState extends State<SceneQuestionsSheet> {
  final _input = TextEditingController();
  String? _answer;
  bool _busy = false;
  @override
  void dispose() { _input.dispose(); super.dispose(); }

  Future<void> _ask(String question) async {
    if (_busy || question.trim().isEmpty) return;
    setState(() { _busy = true; _input.text = question; });
    try {
      final answer = await widget.onQuestion(question);
      if (mounted) setState(() { _answer = answer; });
    } catch (_) {
      if (mounted) setState(() { _answer = 'לא ניתן לענות כרגע. נסה שוב כשהמצלמה פעילה.'; });
    } finally { if (mounted) setState(() { _busy = false; }); }
  }

  @override
  Widget build(BuildContext context) => Padding(
    padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
    child: FractionallySizedBox(heightFactor: .85, child: ListView(
      padding: const EdgeInsets.all(20), children: [
        Row(children: [
          const Expanded(child: Text('שאל על הסביבה', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold))),
          IconButton(onPressed: () => Navigator.pop(context), tooltip: 'חזרה למצלמה', icon: const Icon(Icons.close)),
        ]),
        const Text('התשובה מתייחסת לתמונה הנוכחית בלבד. אפשר לבחור שאלה או להקליד.'),
        const SizedBox(height: 16),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final question in SceneQuestions.examples)
            ActionChip(label: Text(question), onPressed: _busy ? null : () => _ask(question)),
        ]),
        const SizedBox(height: 16),
        TextField(controller: _input, enabled: !_busy, maxLength: 160,
          textInputAction: TextInputAction.send, onSubmitted: _ask,
          decoration: const InputDecoration(labelText: 'השאלה שלך', border: OutlineInputBorder())),
        FilledButton.icon(onPressed: _busy ? null : () => _ask(_input.text),
          icon: const Icon(Icons.question_answer_outlined), label: Text(_busy ? 'בודק את התמונה…' : 'ענה לי')),
        if (_answer != null) Card(child: Padding(padding: const EdgeInsets.all(16),
          child: SelectableText(_answer!, style: const TextStyle(fontSize: 22)))),
      ],
    )),
  );
}
