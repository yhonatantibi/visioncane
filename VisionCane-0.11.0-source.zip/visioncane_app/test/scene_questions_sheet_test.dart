import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:visioncane_app/screens/scene_questions_sheet.dart';

void main() {
  testWidgets('preset question displays answer without requiring a speech engine', (tester) async {
    String? asked;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: SceneQuestionsSheet(onQuestion:(q) async {
      asked=q; return 'דלת מימין בתמונה';
    }))));
    await tester.tap(find.text('איפה הדלת?'));
    await tester.pumpAndSettle();
    expect(asked,'איפה הדלת?');
    expect(find.text('דלת מימין בתמונה'),findsOneWidget);
    expect(tester.takeException(),isNull);
  });
  testWidgets('question sheet scrolls with large Hebrew text', (tester) async {
    tester.view.physicalSize=const Size(360,800); tester.view.devicePixelRatio=1;
    tester.platformDispatcher.textScaleFactorTestValue=2;
    addTearDown(tester.view.resetPhysicalSize); addTearDown(tester.view.resetDevicePixelRatio);
    addTearDown(tester.platformDispatcher.clearTextScaleFactorTestValue);
    await tester.pumpWidget(MaterialApp(home:Scaffold(body:SceneQuestionsSheet(onQuestion:(q) async=>q))));
    expect(tester.takeException(),isNull);
  });
}
