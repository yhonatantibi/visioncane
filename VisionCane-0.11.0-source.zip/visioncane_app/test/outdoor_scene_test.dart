import 'package:flutter_test/flutter_test.dart';
import 'package:visioncane_app/domain/spatial_scene.dart';
import 'package:visioncane_app/domain/scene_narrator.dart';
import 'package:visioncane_app/domain/scene_questions.dart';

void main() {
  test('street regions use actual metadata and preserve image sides', () {
    final features=extractStructures(width:30,height:30,
      classes:List.generate(900,(i)=>i%30<10 ? 0 : i%30>=20 ? 1 : 99),
      labels:['sidewalk','road']);
    expect(features.where((f)=>f.label=='road').every((f)=>f.box.x>2/3),isTrue);
    expect(features.where((f)=>f.label=='sidewalk').every((f)=>f.box.x<1/3),isTrue);
    final s=SpatialScene(frameId:1,receivedAtMs:1000,completedAtMs:1300,features:features,issues:[]);
    expect(SceneQuestions.answer('איפה הכביש?',s,1400),contains('כביש מימין'));
    expect(SceneQuestions.answer('איפה המדרכה?',s,1400),contains('מדרכה משמאל'));
    expect(features.every((f)=>f.depth==null),isTrue);
  });
  test('road spanning sectors is not spoken three times in one overview', () {
    final features=extractStructures(width:30,height:30,classes:List.filled(900,0),labels:['road']);
    expect(features.length,3);
    expect(SceneNarrator.selectOverview(features).length,1);
  });
  test('outdoor questions never infer motion, light color or crossing permission', () {
    final s=SpatialScene(frameId:1,receivedAtMs:1000,completedAtMs:1200,issues:[],features:[
      const SpatialFeature(label:'traffic light',spokenLabel:'רמזור',box:ImageBox(.7,.1,.9,.3))]);
    expect(SceneQuestions.answer('יש רמזור?',s,1400),contains('רמזור מימין'));
    expect(SceneQuestions.answer('אפשר לחצות?',s,1400),contains('אין לי מידע'));
    expect(SceneQuestions.answer('האם רכב מתקרב?',s,1400),contains('אין כאן זיהוי אמין'));
    expect(SceneQuestions.answer('איפה מעבר חצייה?',s,1400),contains('אין כאן זיהוי אמין'));
    expect(SceneQuestions.answer('איזה צבע הרמזור?',s,1400),contains('רק פרטים שזוהו'));
  });
  test('street features outrank decorative clutter', () {
    const box=ImageBox(.1,.1,.5,.5);
    final selected=SceneNarrator.selectOverview([
      const SpatialFeature(label:'vase',spokenLabel:'אגרטל',box:box),
      const SpatialFeature(label:'road',spokenLabel:'כביש',box:box,structure:true),
      const SpatialFeature(label:'person',spokenLabel:'אדם',box:box),
    ],limit:2);
    expect(selected.map((f)=>f.label),['road','person']);
  });
}
