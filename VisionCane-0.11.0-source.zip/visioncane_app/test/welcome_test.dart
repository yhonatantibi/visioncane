import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:visioncane_app/main.dart';
void main() {
  testWidgets('both entry paths work without starting camera', (t) async {
    await t.pumpWidget(const VisionCaneApp());
    await t.tap(find.text('כניסה לשימוש יומיומי')); await t.pumpAndSettle();
    expect(find.text('התחלת שימוש'), findsOneWidget);
    expect(find.text('כלי בדיקה'), findsNothing);
    await t.pageBack(); await t.pumpAndSettle();
    await t.ensureVisible(find.text('כניסה למערכת הבדיקה הקיימת'));
    await t.tap(find.text('כניסה למערכת הבדיקה הקיימת')); await t.pumpAndSettle();
    expect(find.text('כלי בדיקה'), findsOneWidget);
    expect(find.text('המצלמה כבויה'), findsOneWidget);
    await t.pumpWidget(const SizedBox.shrink());
  });
}
