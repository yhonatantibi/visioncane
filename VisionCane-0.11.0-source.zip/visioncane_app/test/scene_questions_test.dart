import 'package:flutter_test/flutter_test.dart';
import 'package:visioncane_app/domain/scene_questions.dart';
import 'package:visioncane_app/domain/scene_narrator.dart';
import 'package:visioncane_app/domain/spatial_scene.dart';

const bed = SpatialFeature(label: 'bed', spokenLabel: 'מיטה', box: ImageBox(.02,.2,.3,.8),
  depth: DepthEstimate(2, 20, .1));
const door = SpatialFeature(label: 'door', spokenLabel: 'דלת', box: ImageBox(.7,.1,.95,.9), structure:true);
SpatialScene scene(List<SpatialFeature> features) => SpatialScene(frameId:1,
  receivedAtMs:1000, completedAtMs:1200, features:features, issues:[]);

void main() {
  test('where and distance answers use current detected position and estimated meters', () {
    final s = scene([bed, door]);
    expect(SceneQuestions.answer('איפה הדלת?',s,1300),contains('דלת מימין'));
    expect(SceneQuestions.answer('מה המרחק למיטה?',s,1300),contains('משוער של שני מטרים'));
    expect(SceneQuestions.answer('מה משמאל?',s,1300),contains('מיטה'));
    expect(SceneQuestions.answer('מה משמאל?',s,1300),isNot(contains('דלת')));
  });
  test('missing, future and stale observations cannot answer locations', () {
    for (final now in [999,3501]) {
      expect(SceneQuestions.answer('איפה הדלת?',scene([door]),now),contains('אין כרגע תמונה עדכנית'));
    }
    expect(SceneQuestions.answer('איפה הדלת?',null,1300),contains('אין כרגע תמונה עדכנית'));
    expect(SceneQuestions.answer('איפה הדלת?',scene([bed]),1300),contains('זה לא אומר'));
  });
  test('unknown distance, open door and safe passage never become assertions', () {
    final s=scene([door]);
    expect(SceneQuestions.answer('מה המרחק לדלת?',s,1300),contains('אין כרגע אומדן מרחק'));
    for (final q in ['הדלת פתוחה?', 'אפשר ללכת?', 'אפשר לחצות?', 'איפה היציאה?']) {
      expect(SceneQuestions.answer(q,s,1300),contains('אין לי מידע שמאפשר לאשר'));
    }
  });
  test('unsupported relationships and contradictory directions do not get guessed answers', () {
    for (final q in ['מה יש ליד הדלת?', 'מה לא רואים?', 'איזה צבע המיטה?']) {
      expect(SceneQuestions.answer(q,scene([door,bed]),1300),contains('רק פרטים שזוהו'));
    }
    expect(SceneQuestions.answer('מה משמאל ומימין?',scene([bed]),1300),contains('כיוון אחד'));
    expect(SceneQuestions.answer('האם יש פיל?',scene([bed]),1300),contains('שאלה נתמכת'));
  });
  test('counts describe detections and remove overlapping duplicates', () {
    const chair=SpatialFeature(label:'chair',spokenLabel:'כיסא',box:ImageBox(.1,.1,.3,.6));
    final answer=SceneQuestions.answer('כמה כיסאות זוהו?',scene([chair,chair,door]),1300);
    expect(answer,contains('זוהו 1 פרטים'));
    expect(answer,contains('ולא ספירה מלאה'));
  });
  test('specific bookcase request does not match every wardrobe', () {
    const books=SpatialFeature(label:'bookcase',spokenLabel:'ארון ספרים',box:ImageBox(.4,.1,.6,.8));
    const wardrobe=SpatialFeature(label:'wardrobe',spokenLabel:'ארון בגדים',box:ImageBox(.7,.1,.9,.8));
    final answer=SceneQuestions.answer('איפה ארון ספרים?',scene([books,wardrobe]),1300);
    expect(answer,contains('ארון ספרים'));
    expect(answer,isNot(contains('ארון בגדים')));
  });
  test('room anchors outrank small clutter regardless of incoming order', () {
    const cup=SpatialFeature(label:'cup',spokenLabel:'כוס',box:ImageBox(.1,.1,.2,.2));
    final selected=SceneNarrator.selectOverview([cup,bed,door],limit:2);
    expect(selected.map((f)=>f.label).toList(),['door','bed']);
  });
}
