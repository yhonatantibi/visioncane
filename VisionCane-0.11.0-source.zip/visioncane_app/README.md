# VisionCane 0.10.0 — indoor and outdoor descriptions

This release adds outdoor scene categories to the EXISTING ADE20K model output, without another model, cloud connection, API account or paid service.

New semantic categories interpreted from actual embedded metadata: road, sidewalk, path, fence, railing/bannister, pole, building, tree and step (stairs). Class IDs are never hard-coded. Road, sidewalk and pole observations receive high narration priority. A road spanning three image sectors is not narrated three times in one overview.

The existing object detector contributes people, cars, buses, trucks, bicycles, motorcycles, traffic lights, stop signs and benches. New question presets include road, sidewalk, traffic light and people. Vehicle questions support multiple vehicle classes. Region counts are not represented as object counts. Motion, traffic-light color, crossing permission and crosswalk questions do not produce fabricated answers.

This is description of a camera image, NOT navigation. No crosswalk detector, moving-vehicle tracker, traffic-light state classifier, GPS route guidance, curb/drop-off detector or clear-path guarantee is implemented. The additional category support does not establish real-world detection accuracy. Distance remains optional and uncalibrated. The reported tablet crash has not been verified fixed on a device.

Validation: automated tests cover category-to-region mapping, correct image sides, repeated-region suppression, question limits and narration priority. These are synthetic observations, not a field accuracy test.

Reference for supported labels: https://github.com/ultralytics/ultralytics/blob/main/ultralytics/cfg/datasets/ade20k.yaml

Upload both files from VisionCane-Upload-2-Files to the GitHub root without extracting the ZIP; start a NEW Codemagic android-demo build and install that build's APK. This folder holds source plus build configuration, not an APK.

---

# VisionCane 0.9.0 — scene questions and relevant overviews

User-visible changes from 0.7:
- Live camera with detector overlays, large describe/stop controls and speech mute.
- New Ask about the environment sheet: preset Hebrew questions and typed input, answers displayed immediately and spoken when speech is enabled. Automatic narration pauses while the sheet is open. Closing it interrupts the answer and leaves a quiet interval.
- Supported questions: where a listed object was detected, what was detected left/right/center, estimated distance when available, detection counts, and a current-view overview. Each answer reads evidence at submission time. No scene older than 2.5 seconds is used.
- Room overviews prioritize stairs, doors, people/vehicles and major furniture over small clutter. Wardrobes, cabinets, bookcases and dressers are included from actual semantic labels.
- Hebrew display labels expanded for the detector categories.
- Default live mode uses detector plus indoor model. Experimental depth is off unless enabled in settings before starting. Indoor input is 320 pixels, auxiliary models use CPU and load sequentially.

How to use: start detection, wait for camera/model readiness, press Ask about the environment, select Where is the door? / What is on the left? or type a supported question. Keep camera pointed at the scene. Distance questions report unavailable when depth is disabled or invalid.

Boundaries: questions use an offline rules-based interpreter over observed objects, NOT an open-ended language model. There is no microphone speech recognition in this release. Unknown relationships, colors, text, door-open state, safe crossings and whole-room maps are not inferred. No new object/road-crossing detector was added. The system does not identify everything.

Build and device status: source release for Codemagic, not a locally built APK. Unit/widget tests cannot establish real-device performance, reliable perception or crash resolution. This remains a demonstration candidate and must not be handed over as an independent navigation system.

Upload: the ZIP and codemagic.yaml from VisionCane-Upload-2-Files go together at the GitHub repository root. Do not extract the ZIP for upload. Run a new android-demo build and install its app-debug.apk. Never reuse an old build artifact.

---

# VisionCane 0.8.1 — demonstration candidate

This is source for a build, not a device-validated finished navigation product.

Changes:
- Live camera and object overlays, concise Hebrew scene narration, describe-now, door search, mute and stop controls.
- Indoor semantic model at 320 pixels on CPU. Depth is OFF by default: camera detector plus one indoor model, rather than three resident models. Experimental depth can be enabled before starting in settings, with higher resource use.
- Wardrobe, cabinet, bookcase and chest-of-drawers regions now enter narration using actual model metadata. Connected regions remain separate. No extra furniture model is loaded.
- Live screen shows room-model readiness and whether distance is enabled.
- Live auxiliary models are released before opening saved-photo analysis to avoid retaining duplicate sets of models.

Remaining limits:
- No device crash trace was available. Reduced model load is mitigation, not proof that the reported device crash is fixed.
- Door detection and speech quality require a real-device check. A door is not a verified exit or clear passage.
- Optional distances are uncalibrated model estimates. Image-left/right are relative to the camera, not a body bearing. There is no whole-room map or supported crossing guidance.
- First use still needs internet for the detector (and depth if enabled); the indoor model is bundled by CI. Offline voices must already be installed.

Build: upload the two files from VisionCane-Upload-2-Files to the repository root, without extracting the ZIP. Commit, run android-demo, install its new app-debug.apk. Old builds are unchanged.

Before tomorrow's demonstration: at a fixed seated position with a sighted helper, confirm camera starts, spoken left/right match the camera view, stop interrupts speech, and the app runs without freezing for ten minutes. Do not use this candidate to guide walking or road crossing. If startup fails, do not present it as a working assistive device.

---

# Current release: 0.7.0 prototype candidate

See [0.7.0 update and installation](docs/UPDATE-0.7.0.md). The indoor model is exported and verified during CI; native build and device validation are pending. Earlier status below is historical.

# VisionCane 0.5.0 — תיאור עצמים ומרחב מתמונה משותפת

אפליקציית Flutter לאנדרואיד ולאייפון. גרסת ניסוי שמחברת זיהוי עצמים, אומדן עומק וסיווג מבנה המרחב, ומקריאה את התוצאה בעברית. נדרשת בנייה ובדיקת מכשיר לגרסה זו לפני שימוש בהדגמה.

## מה השתנה מ-0.4

במסך הדגמה המתג ״עצמים, מרחק ומבנה ביחד״ מופעל כברירת מחדל. מצלמה אחת מפיקה תמונה וזיהויי עצמים מאותה תמונה; אותה תמונה מועברת למודל מרחק ולמודל מבנה. אין איסוף מרחק מתמונה מאוחרת והדבקתו לזיהוי מתמונה מוקדמת.

ההקראה כוללת שם, אחד מתשעה אזורים בתמונה, ואומדן מרחק כשיש נתון תקין. לדוגמה: ״כיסא משמאל בתמונה, בחלק האמצעי, במרחק משוער של שני מטרים״. דלתות, קירות, רצפה, תקרה, חלונות ומדרגות מתוארים רק אם קטגוריות אלה נמצאות במטא־דטה של מודל המבנה ותוצאתו תומכת בכך.

״תאר עכשיו״ מקריא עד ארבעה פרטים, עם פרט מבני אחד כשזוהה. הרשימה מציגה את כל הפרטים שהתקבלו בניתוח. תיאור אוטומטי דורש הופעה בשתי תוצאות משולבות עוקבות, עם רווח של חמש שניות לאחר משפט וצינון חזרה של 12 שניות לקטגוריה באזור תמונה. אין מעקב זהות אחרי עצמים.

אם אין אומדן תקין נאמר ״המרחק אינו זמין״. נתונים ישנים מ-2.5 שניות מרגע הגעת תמונת האירוע אינם מוצגים או מתחילים הקראה. זה אינו זמן צילום-עד-הקראה מדוד; עצם ההקראה נמשך בזמן.

## מודלים ופעולה מקומית

- yolo26n — זיהוי קטגוריות עצמים מוכרות.
- yolo26n-depth — אומדן מונוקולרי של מרחק במטרים לפי פורמט התוסף.
- yolo26n-sem — סיווג אזורים בתמונה לפי קטגוריות המודל; מיפוי המספרים נלקח ממטא־דטה, ולא מטבלה משוערת.

שלושת המודלים פועלים על המכשיר. בהפעלה הראשונה יש הורדה של המודלים. תמונות מועברות בין רכיבי העיבוד בזיכרון ואינן נשמרות או מועלות בקוד האפליקציה. אין בקשת מיקרופון או מיקום. אחרי הכנה צריך לבדוק פתיחה מחדש במצב טיסה ו-Wi-Fi כבוי.

## ביצועים

זיהוי העצמים ממשיך בזרם המצלמה, בעוד ניתוח משולב מתחיל לכל היותר פעם בשנייה. מודלי העומק והמבנה מעבדים את אותה תמונה בזה אחר זה כדי לצמצם תחרות על GPU. זו פעולה משולבת בזמן שימוש אחד, ואינה הבטחה שכל פריים מעובד בשלושה מודלים או שהמודלים רצים בו-זמנית בחומרה.

יש רק תמונה משולבת אחת בעיבוד, ללא תור מתארך. תוצאות שהגיעו אחרי עצירה, רקע או הפעלת מצלמה חדשה נדחות. קצב העדכון עם שלושה מודלים ב-SM-X510 וב-iPhone 13 עדיין לא נמדד. מדד FPS של גלאי העצמים אינו קצב הניתוח המשולב. אבחון מציג בנפרד את מספר הניתוחים וזמן אירוע-עד-השלמה.

אם ניתוח איטי מדי, יוצג שאין תיאור משולב עדכני. אפשר לכבות את המתג כשהמצלמה כבויה ולחזור לזיהוי העצמים הקודם. ראו docs/SPATIAL.md.

## מגבלות משמעותיות

המרחק הוא אומדן מודל לא מכויל, ולא מדידת חיישן או מרחק בטוח להליכה. דגימה מתוך מרכז תיבת עצם עשויה לכלול רקע או עצם אחר; דגימות מעטות, שגויות או מפוזרות מדי נדחות, אך אין בכך הבטחה לדיוק.

המיקום הוא בתמונה של המצלמה האחורית, בתשעה אזורים. אין כיוון ביחס לגוף, זווית מדויקת או מפה של המבנה. זיהוי דלת אינו מוכיח שהיא פתוחה, ניתנת למעבר, כניסה או יציאה. זיהוי רצפה אינו אומר שהמסלול פנוי. אין עדיין זיהוי אמין של כל מכשולי הדרך, בורות או כבלים, ואין הנחיית הליכה עצמאית.

## קול וממשק

נשמר תיקון הקול מ-0.4: flutter_tts מחזיר network_required כמחרוזת 0/1, והקוד מקבל מחרוזת 0 ודוחה קול רשת וערך לא ידוע. קול נבחר מתוך קולות מותקנים. הפעלה, עצירת הכול, תיאור לפי בקשה, טופס בדיקה, דוחות ואבחון זמינים בעברית. נדרשות בדיקות TalkBack ו-VoiceOver פיזיות.

## בנייה והתקנה

Flutter 3.47.7, Dart 3.13.5, Node 20 ומעלה. התלויות הישירות וקובץ pubspec.lock מקובעים. קובצי Android/iOS נוצרים ב-bootstrap. מינימום Android API 24 ו-iOS 15.

```sh
node tool/check_layout.mjs
node --test tool/native_config.test.mjs
node tool/bootstrap.mjs
dart tool/domain_smoke.dart
dart tool/spatial_smoke.dart
flutter analyze
flutter test --reporter expanded
flutter build apk --debug
```

ב-Codemagic בחר main ומסלול android-demo לאחר העלאת התוכן המעודכן. יש לשמור על lib/domain, lib/services, lib/screens, test, tool ו-docs. אין להעלות ZIP או תיקייה עוטפת סביב pubspec.yaml. פלט Android להתקנה הוא app-debug.apk. פלט iOS ללא חתימה אינו מתקין אפליקציה באייפון; נדרשים חשבון וחתימה מתאימים.

## בדיקה לפני הצגה

פעל לפי docs/SPATIAL.md למדידת מרחקים מול סרט מדידה, שיוך עצמים לאזורים, קירות ודלתות, פתחים שאינם יציאה ובדיקות רקע/עצירה. בדוק במיוחד שהמערכת אינה מקריאה נתון ישן אחרי הזזת מצלמה. יש לתעד גם החמצות, מרחק שגוי ותיוג מבני שגוי. אין להסתמך על דוגמה מוצלחת אחת.

יומן הבדיקות נשמר במכשיר וניתן להעתקה או שיתוף כ-JSON. מצב integrated_scene נשמר בנפרד מ-detect ומ-depth_experiment. הסרת אפליקציה יכולה למחוק דוחות ומודלים; יצא דוחות חשובים קודם.

## אימות ומקורות

ראו docs/STATUS.md למצב הרצות בפועל. ממשקי עומק, סמנטיקה, מודלים וייצוא תמונה נבדקו במקור חבילת ultralytics_yolo 0.6.16 וב-doc/usage.md, doc/api.md. סינון, שיוך ומדיניות תיאור נבדקים ב-tool/spatial_smoke.dart; בדיקה זו אינה מודדת דיוק מודל או ביצועי מכשיר. תנאי התלויות מופיעים ב-docs/THIRD_PARTY.md.
