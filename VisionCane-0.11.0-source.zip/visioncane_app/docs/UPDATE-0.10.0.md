# VisionCane 0.10.0 — indoor and outdoor descriptions

This release adds outdoor scene categories to the EXISTING ADE20K model output, without another model, cloud connection, API account or paid service.

New semantic categories interpreted from actual embedded metadata: road, sidewalk, path, fence, railing/bannister, pole, building, tree and step (stairs). Class IDs are never hard-coded. Road, sidewalk and pole observations receive high narration priority. A road spanning three image sectors is not narrated three times in one overview.

The existing object detector contributes people, cars, buses, trucks, bicycles, motorcycles, traffic lights, stop signs and benches. New question presets include road, sidewalk, traffic light and people. Vehicle questions support multiple vehicle classes. Region counts are not represented as object counts. Motion, traffic-light color, crossing permission and crosswalk questions do not produce fabricated answers.

This is description of a camera image, NOT navigation. No crosswalk detector, moving-vehicle tracker, traffic-light state classifier, GPS route guidance, curb/drop-off detector or clear-path guarantee is implemented. The additional category support does not establish real-world detection accuracy. Distance remains optional and uncalibrated. The reported tablet crash has not been verified fixed on a device.

Validation: automated tests cover category-to-region mapping, correct image sides, repeated-region suppression, question limits and narration priority. These are synthetic observations, not a field accuracy test.

Reference for supported labels: https://github.com/ultralytics/ultralytics/blob/main/ultralytics/cfg/datasets/ade20k.yaml

Upload both files from VisionCane-Upload-2-Files to the GitHub root without extracting the ZIP; start a NEW Codemagic android-demo build and install that build's APK. This folder holds source plus build configuration, not an APK.
