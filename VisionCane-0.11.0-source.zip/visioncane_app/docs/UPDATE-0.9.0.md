# VisionCane 0.9.0 — scene questions and relevant overviews

User-visible changes from 0.7:
- Live camera with detector overlays, large describe/stop controls and speech mute.
- New Ask about the environment sheet: preset Hebrew questions and typed input, answers displayed immediately and spoken when speech is enabled. Automatic narration pauses while the sheet is open. Closing it interrupts the answer and leaves a quiet interval.
- Supported questions: where a listed object was detected, what was detected left/right/center, estimated distance when available, detection counts, and a current-view overview. Each answer reads evidence at submission time. No scene older than 2.5 seconds is used.
- Room overviews prioritize stairs, doors, people/vehicles and major furniture over small clutter. Wardrobes, cabinets, bookcases and dressers are included from actual semantic labels.
- Hebrew display labels expanded for the detector categories.
- Default live mode uses detector plus indoor model. Experimental depth is off unless enabled in settings before starting. Indoor input is 320 pixels, auxiliary models use CPU and load sequentially.

How to use: start detection, wait for camera/model readiness, press Ask about the environment, select Where is the door? / What is on the left? or type a supported question. Keep camera pointed at the scene. Distance questions report unavailable when depth is disabled or invalid.

Boundaries: questions use an offline rules-based interpreter over observed objects, NOT an open-ended language model. There is no microphone speech recognition in this release. Unknown relationships, colors, text, door-open state, safe crossings and whole-room maps are not inferred. No new object/road-crossing detector was added. The system does not identify everything.

Build and device status: source release for Codemagic, not a locally built APK. Unit/widget tests cannot establish real-device performance, reliable perception or crash resolution. This remains a demonstration candidate and must not be handed over as an independent navigation system.

Upload: the ZIP and codemagic.yaml from VisionCane-Upload-2-Files go together at the GitHub repository root. Do not extract the ZIP for upload. Run a new android-demo build and install its app-debug.apk. Never reuse an old build artifact.
