# 0.8.0 — Camera experience and reduced resource demand

This is a development candidate, not a validated finished navigation product.

- During a camera session, the live camera and native detection overlays occupy the main screen; the latest spoken description appears on top. Describe, door search and stop remain directly accessible.
- Auxiliary structure and depth models load sequentially, on CPU. The camera detector may still use the GPU. No claim is made that all inference is serialized across the camera and auxiliary workers.
- The indoor model is exported at 320 instead of 640 pixels per side. Spatial activation tensor sizes generally decrease with image area; this is not a measured total-memory reduction. Door recall can decrease at the smaller size.
- Auxiliary analysis starts no more often than once per 1700 ms and does not enqueue frames while inference is busy.
- The model asset is versioned v2, and export cache validation includes input size, preventing reuse of the older 640 model.

The cause of the reported device crash has not been confirmed by native logs. These changes address resource pressure and do not establish that the crash is fixed. Static analysis was run; native build, runtime stability and recognition accuracy require validation on the target device.

Current scope: object and indoor structural categories, short evidence-based image descriptions, approximate uncalibrated depth. No verified crosswalk detection, complete room map, reliable street situation understanding, validated metric ranging or independent walking guidance. Do not use model omissions as evidence that a path is clear.

Upload only the ZIP and codemagic.yaml from VisionCane-Upload-2-Files. The build restores source paths and exports the actual mobile indoor model before building the APK. Preserve earlier release notes as history.
