# 0.11.0 — two entry experiences

New welcome screen offers daily use or the existing test system. Daily use hides research navigation and live diagnostics, offers a large start button, voice check, automatic-description preference, and the existing functional camera/questions/stop controls. Returning to the welcome screen permits entering the test system. Camera starts only on explicit request.

This is a local entry-mode choice, not authentication, a registered account or saved personal profile. No external service or payment added. Perception capabilities and limitations are unchanged; native-device accuracy and crash behavior remain unverified.
