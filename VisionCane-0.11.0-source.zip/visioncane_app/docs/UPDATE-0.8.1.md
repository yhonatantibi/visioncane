# VisionCane 0.8.1 — demonstration candidate

This is source for a build, not a device-validated finished navigation product.

Changes:
- Live camera and object overlays, concise Hebrew scene narration, describe-now, door search, mute and stop controls.
- Indoor semantic model at 320 pixels on CPU. Depth is OFF by default: camera detector plus one indoor model, rather than three resident models. Experimental depth can be enabled before starting in settings, with higher resource use.
- Wardrobe, cabinet, bookcase and chest-of-drawers regions now enter narration using actual model metadata. Connected regions remain separate. No extra furniture model is loaded.
- Live screen shows room-model readiness and whether distance is enabled.
- Live auxiliary models are released before opening saved-photo analysis to avoid retaining duplicate sets of models.

Remaining limits:
- No device crash trace was available. Reduced model load is mitigation, not proof that the reported device crash is fixed.
- Door detection and speech quality require a real-device check. A door is not a verified exit or clear passage.
- Optional distances are uncalibrated model estimates. Image-left/right are relative to the camera, not a body bearing. There is no whole-room map or supported crossing guidance.
- First use still needs internet for the detector (and depth if enabled); the indoor model is bundled by CI. Offline voices must already be installed.

Build: upload the two files from VisionCane-Upload-2-Files to the repository root, without extracting the ZIP. Commit, run android-demo, install its new app-debug.apk. Old builds are unchanged.

Before tomorrow's demonstration: at a fixed seated position with a sighted helper, confirm camera starts, spoken left/right match the camera view, stop interrupts speech, and the app runs without freezing for ten minutes. Do not use this candidate to guide walking or road crossing. If startup fails, do not present it as a working assistive device.
